package com.example.comp2008assignment1

import android.content.Context
import androidx.core.content.edit

class RatingStore(context: Context) {
    private val prefs = context.getSharedPreferences("rating_store", Context.MODE_PRIVATE)

    fun getRating(id: String): Float = prefs.getFloat("rating_$id", 0f)
    fun setRating(id: String, value: Float) = prefs.edit { putFloat("rating_$id", value) }

    fun isVisited(id: String): Boolean = prefs.getBoolean("visited_$id", false)
    fun setVisited(id: String, value: Boolean) = prefs.edit { putBoolean("visited_$id", value) }

}